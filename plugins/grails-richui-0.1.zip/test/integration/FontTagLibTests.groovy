class FontTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}