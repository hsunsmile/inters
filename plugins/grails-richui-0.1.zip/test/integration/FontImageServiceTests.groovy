class FontImageServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}