class TreeViewTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
