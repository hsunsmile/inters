
class SifrGrailsPlugin {

	def version = 0.1
	def dependsOn = [:]
	
	def doWithSpring = {
	}   

	def doWithApplicationContext = { applicationContext ->
	}

	def doWithWebDescriptor = {
	}	                                      

	def onChange = { event ->
	}                                                                                  

	def onApplicationChange = { event ->
	}

}
