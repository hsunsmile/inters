package grails.converters.exceptions;

public class ConverterException extends Exception {

    private static final long serialVersionUID = -4211512662882252140L;

    public ConverterException(String message, Throwable cause) {
        super(message, cause);
    }

    public ConverterException(String message) {
        super(message);
    }

    public ConverterException(Throwable cause) {
        super(cause);
    }

    public ConverterException() {
    }

    public String getMessage() {
        return super.getMessage();
    }

}
