package grails.converters.xstream;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import grails.converters.ConverterUtil;
import org.codehaus.groovy.grails.commons.GrailsDomainClass;
import org.codehaus.groovy.grails.commons.GrailsDomainClassProperty;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class DomainClassConverter implements Converter {

    public DomainClassConverter() {

    }

    public void marshal(Object value, HierarchicalStreamWriter writer,
                        MarshallingContext context) {

        Class clazz = value.getClass();
        GrailsDomainClass domainClass = ConverterUtil.getDomainClass(clazz.getName());
        BeanWrapper beanWrapper = new BeanWrapperImpl(value);


        GrailsDomainClassProperty id = domainClass.getIdentifier();

        Object idValue = extractIdValue(value, id);
        if (idValue != null) writer.addAttribute("id", String.valueOf(idValue));

        GrailsDomainClassProperty[] properties = domainClass.getPersistentProperties();

        for (int i = 0; i < properties.length; i++) {
            GrailsDomainClassProperty property = properties[i];
            writer.startNode(property.getName());
            if (!property.isAssociation()) {
                // Write non-relation property
                Object val = beanWrapper.getPropertyValue(property.getName());
                if (val == null) {
                    writer.startNode("null");
                    writer.endNode();
                } else {
                    context.convertAnother(val);
                }
            } else {
                Object referenceObject = beanWrapper.getPropertyValue(property.getName());

                if (referenceObject == null) {
                    writer.startNode("null");
                    writer.endNode();
                } else {
                    GrailsDomainClass referencedDomainClass = property.getReferencedDomainClass();
                    GrailsDomainClassProperty referencedIdProperty = referencedDomainClass.getIdentifier();
                    if (property.isOneToOne() || property.isManyToOne() || property.isEmbedded()) {
                        // Property contains 1 foreign Domain Object
                        writer.startNode(referencedDomainClass.getPropertyName());
                        writer.addAttribute("id", String.valueOf(extractIdValue(referenceObject, referencedIdProperty)));
                        writer.endNode();
                    } else {
                        String refPropertyName = referencedDomainClass.getPropertyName();
                        if (referenceObject instanceof Collection) {
                            Collection o = (Collection) referenceObject;
                            for (Iterator it = o.iterator(); it.hasNext();) {
                                Object el = (Object) it.next();
                                writer.startNode(refPropertyName);
                                writer.addAttribute("id", String.valueOf(extractIdValue(el, referencedIdProperty)));
                                writer.endNode();
                            }

                        } else if (referenceObject instanceof Map) {
                            Map map = (Map) referenceObject;
                            Iterator iterator = map.keySet().iterator();
                            while (iterator.hasNext()) {
                                String key = String.valueOf(iterator.next());
                                Object o = map.get(key);
                                writer.startNode("entry");
                                writer.startNode("string"); // key of map entry has to be a string
                                writer.setValue(key);
                                writer.endNode(); // end string
                                writer.startNode(refPropertyName);
                                writer.addAttribute("id", String.valueOf(extractIdValue(o, referencedIdProperty)));
                                writer.endNode(); // end refPropertyName
                                writer.endNode(); // end entry
                            }
                        }
                    }
                }
            }
            writer.endNode();
        }
    }

    public Object unmarshal(HierarchicalStreamReader reader,
                            UnmarshallingContext context) {
//        Under development: 
//        try {
//            Class clazz = context.getRequiredType();
//            GrailsDomainClass domainClass = ConverterUtil.getDomainClass(clazz.getName());
//            Object o = clazz.newInstance();
//            BeanWrapper beanWrapper = new BeanWrapperImpl(o);
//            //GroovyObject go = (GroovyObject) clazz.newInstance();
//
//            while (reader.hasMoreChildren()) {
//                reader.moveDown();
//                String propertyName = reader.getNodeName();
//                GrailsDomainClassProperty property = domainClass.getPropertyByName(propertyName);
//
//                if (property.isAssociation()) {
//                    //  TODO
//                } else {
//                    Object value = context.convertAnother(o, property.getType());
//                    beanWrapper.setPropertyValue(property.getName(), value);
//                }
//                reader.moveUp();
//            }
//
//            return null;
//        } catch (Exception e) {
//            throw new UnhandledException(e);
//        }
        return null;
    }

    public boolean canConvert(Class clazz) {
        return ConverterUtil.isDomainClass(clazz);
    }

    private Object extractIdValue(Object domainObject, GrailsDomainClassProperty idProperty) {
        BeanWrapper beanWrapper = new BeanWrapperImpl(domainObject);
        return beanWrapper.getPropertyValue(idProperty.getName());
    }

}
