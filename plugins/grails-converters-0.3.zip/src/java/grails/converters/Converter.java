package grails.converters;

import grails.converters.exceptions.ConverterException;

import javax.servlet.http.HttpServletResponse;
import java.io.Writer;

public interface Converter {

    public void render(Writer out) throws ConverterException;

    public void render(HttpServletResponse response) throws ConverterException;

}
