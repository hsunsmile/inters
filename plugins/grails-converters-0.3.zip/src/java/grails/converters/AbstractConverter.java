package grails.converters;

import org.apache.commons.lang.UnhandledException;

import java.io.StringWriter;

public abstract class AbstractConverter implements Converter {

    public AbstractConverter() {

    }

    public abstract void setTarget(Object target);

    public String toString() {
        StringWriter writer = new StringWriter();
        try {
            render(writer);
        } catch (Exception e) {
            throw new UnhandledException(e);
        }
        return writer.toString();
    }
}