package grails.converters;

import com.thoughtworks.xstream.XStream;
import grails.converters.exceptions.ConverterException;
import grails.converters.xstream.DomainClassConverter;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;

public class XML extends AbstractConverter implements Converter {

    public static final Logger log = Logger.getLogger(XML.class);

    private Object target;

    private static XStream xstream;

    public static XStream getXStream() {
        if (xstream == null) {
            xstream = setupXStream();
        }
        return xstream;
    }

    public static void addAlias(String alias, Class clazz) {
        getXStream().alias(alias, clazz);
    }

    public static XStream setupXStream() {
        XStream xstream = new XStream();
        xstream.registerConverter(new DomainClassConverter(), XStream.PRIORITY_VERY_HIGH);
        xstream.setMode(XStream.XPATH_ABSOLUTE_REFERENCES);
        return xstream;
    }

    public XML() {

    }

    public XML(Object target) {
        this.target = target;
    }

    public void render(Writer out) throws ConverterException {
        getXStream().toXML(target, out);
    }

    public void render(HttpServletResponse response) throws ConverterException {
        response.setContentType("text/xml");
        try {
            Writer writer = response.getWriter();
            String encoding = response.getCharacterEncoding();
            writer.write("<?xml version=\"1.0\" encoding=\"" + encoding + "\"?>");
            render(writer);
        } catch (IOException e) {
            throw new ConverterException(e);
        }
    }

    public void setTarget(Object target) {
        this.target = target;
    }

    public Object asType(Class type) {
        return null;
    }

}
