import org.codehaus.groovy.grails.plugins.support.*
import grails.converters.*
import org.codehaus.groovy.grails.commons.ControllerArtefactHandler
import org.codehaus.groovy.grails.commons.metaclass.ExpandoMetaClass

class ConvertersGrailsPlugin {
	def version = 0.3
	def author = "Siegfried Puchbauer"
	def title = "Provides JSON and XML Conversion for common Objects (Domain Classes, Lists, Maps, POJO)"
	def description = """
		The grails-converters plugin aims to give you the ability to convert your domain objects, maps and lists to JSON or XML very quickly, to ease development for AJAX based applications. The plugin leverages the the groovy "as" operator and extends the render method in grails controllers to directly send the result to the output stream. It also adds the Grails Codecs mechanism for XML and JSON.
	"""
	def documentation = "http://grails.org/Converters+Plugin"
	
	def dependsOn = [
	    controllers: GrailsPluginUtils.getGrailsVersion(),
	    hibernate: GrailsPluginUtils.getGrailsVersion(),
	    domainClass: GrailsPluginUtils.getGrailsVersion()
	]

	def doWithDynamicMethods = { applicationContext ->
        ConverterUtil.setGrailsApplication(application);

        def controllers = application.getArtefacts(ControllerArtefactHandler.TYPE)
		controllers.each { controller ->
		    def mc = controller.metaClass
			mc.render = { Converter converter ->
					converter.render(delegate.response);
			}

			mc.header = { String key, def value ->
				if(value) delegate.response?.setHeader(key, value.toString())
			}

			mc.jsonHeader = { def value ->
			    if(value) delegate.response?.setHeader("X-JSON", value.toString())
			}
		}

        application.domainClasses.each { dc ->
            def mc = dc.metaClass
            mc.asType = { Class clazz ->
                if(ConverterUtil.isConverterClass(clazz)) {
                    return ConverterUtil.createConverter(clazz, delegate)
                } else {
                    return ConverterUtil.invokeOriginalAsTypeMethod(delegate, clazz)
                }
            }
            XML.addAlias(dc.propertyName, dc.clazz);
            log.debug "Adding XStream alias ${dc.propertyName} for class ${dc.clazz.getName()}"
        }

        [Collection,List,Set,ArrayList,HashSet,TreeSet, Object].each { collectionClass ->
			def metaClass = new ExpandoMetaClass(collectionClass, true)
			metaClass.asType = { Class clazz ->
				if(ConverterUtil.isConverterClass(clazz)) {
					return ConverterUtil.createConverter(clazz, delegate);
				} else {
					return ConverterUtil.invokeOriginalAsTypeMethod(delegate, clazz)
				}
			}
			metaClass.initialize()
		}
		log.info "Converters Plugin configured successfully"
	}
}