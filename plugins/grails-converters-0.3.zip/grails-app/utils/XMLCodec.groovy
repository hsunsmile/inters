import grails.converters.XML

class XMLCodec {

	static encode = { target ->
		return new XML(target).toString()
	}
	
}