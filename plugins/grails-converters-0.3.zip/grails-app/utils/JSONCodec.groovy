import grails.converters.JSON

class JSONCodec {

	static encode = { target ->
		return new JSON(target).toString(true)
	}
	
}